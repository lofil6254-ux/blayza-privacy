AR Draw Anime: Trace Sketch - press assets
Free to use in articles about the app.

Play Store: https://play.google.com/store/apps/details?id=com.artracing.studio
Press page: https://lofil6254-ux.github.io/blayza-privacy/press.html
Contact: saadfellak0000@gmail.com
